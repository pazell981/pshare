
module.exports = {

	'facebookAuth' : {
		'clientID' 		: '475092382630434',
		'clientSecret' 	: '60365af60763794fd38bbebeedf46bec',
		'callbackURL' 	: 'http://rememberwhenwe.elasticbeanstalk.com/auth/facebook/callback'
	},

	'twitterAuth' : {
		'consumerKey' 		: 'kkigdCeqSFJjQZi6mgvJDdVZ3',
		'consumerSecret' 	: '3ucCR1zPV64sL4un912NMLAfOl1Ws5BZnHZbJY37RG6vM9UeFz',
		'callbackURL' 		: 'http://rememberwhenwe.elasticbeanstalk.com/auth/twitter/callback'
	},

	'googleAuth' : {
		'clientID' 		: '609171465478-vrbbvlrcl7u4h00atnc8ufg81vpkghtc.apps.googleusercontent.com',
		'clientSecret' 	: 'uXynv7Xd1H4z95fS4rzBpx0d',
		'callbackURL' 	: 'http://rememberwhenwe.elasticbeanstalk.com/auth/google/callback'
	}

};