module.exports = {

	'facebookAuth' : {
		'clientID' 		: '475092382630434',
		'clientSecret' 	: "60365af60763794fd38bbebeedf46bec",
		'callbackURL' 	: 'http://rww-dev.elasticbeanstalk.com/auth/facebook/callback'
	},

	'twitterAuth' : {
		'consumerKey' 		: 'kkigdCeqSFJjQZi6mgvJDdVZ3',
		'consumerSecret' 	: "uXynv7Xd1H4z95fS4rzBpx0d",
		'callbackURL' 		: 'http://rww-dev.elasticbeanstalk.com/auth/twitter/callback'
	},

	'googleAuth' : {
		'clientID' 		: '609171465478-vrbbvlrcl7u4h00atnc8ufg81vpkghtc.apps.googleusercontent.com',
		'clientSecret' 	: "uXynv7Xd1H4z95fS4rzBpx0d",
		'callbackURL' 	: 'http://rww-dev.elasticbeanstalk.com/auth/google/callback'
	}

};